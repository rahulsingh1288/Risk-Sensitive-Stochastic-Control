% clear all;close all;clc
% load Policy_Compare
figure;hold on;
plot(DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.Lambda_simu,'ro')
plot(TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.Lambda_simu,'bx')
legend('DelverDebt','TimeDebt')
title('\Lambda=1/\theta lnE[exp(\theta l(x))]')

figure;hold on;
temp_show=(DeliverDebt_SimuResult.Positive_S+[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
plot(DeliverDebt_SimuResult.myTheta,sum(temp_show,2),'ro');
temp_show=(TimeDebt_SimuResult.Positive_S+[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
plot(TimeDebt_SimuResult.myTheta,sum(temp_show,2),'bx');
legend('DelverDebt','TimeDebt')
title('E[S_i^+]+\theta Var(S_i^+) ( normed by E[S_i])')


figure;hold on;
subplot(1,2,1);hold on;
plot(DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.mean_S(:,1),'ro')
plot(TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.mean_S(:,1),'bx')
xlabel('\theta')
legend('DelverDebt','TimeDebt')
title('mean sensing interval for user 1')
subplot(1,2,2);hold on;
plot(DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.mean_S(:,2),'ro')
plot(TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.mean_S(:,2),'bx')
legend('DelverDebt','TimeDebt')
xlabel('\theta')
title('mean sensing interval for user 2')


figure;hold on;
subplot(1,2,1);hold on;
temp_show_D=DeliverDebt_SimuResult.Square_S-(DeliverDebt_SimuResult.mean_S).^2;
temp_show_T=TimeDebt_SimuResult.Square_S-(TimeDebt_SimuResult.mean_S).^2;
plot(DeliverDebt_SimuResult.myTheta,temp_show_D(:,1),'ro')
plot(TimeDebt_SimuResult.myTheta,temp_show_T(:,1),'bx')
xlabel('\theta')
legend('DelverDebt','TimeDebt')
title('variance of sensing interval for user 1')
subplot(1,2,2);hold on;
plot(DeliverDebt_SimuResult.myTheta,temp_show_D(:,2),'ro')
plot(TimeDebt_SimuResult.myTheta,temp_show_T(:,2),'bx')
legend('DelverDebt','TimeDebt')
xlabel('\theta')
title('variance of sensing interval for user 2')

figure;hold on;
subplot(1,2,1);hold on;
temp_show_D=DeliverDebt_SimuResult.Square_S-(DeliverDebt_SimuResult.mean_S).^2;
temp_show_D=temp_show_D./(DeliverDebt_SimuResult.mean_S).^2;
temp_show_T=TimeDebt_SimuResult.Square_S-(TimeDebt_SimuResult.mean_S).^2;
temp_show_T=temp_show_T./(TimeDebt_SimuResult.mean_S).^2;
plot(DeliverDebt_SimuResult.myTheta,temp_show_D(:,1),'ro')
plot(TimeDebt_SimuResult.myTheta,temp_show_T(:,1),'bx')
xlabel('\theta')
legend('DelverDebt','TimeDebt')
title('coefficient of variance for S1')
subplot(1,2,2);hold on;
plot(DeliverDebt_SimuResult.myTheta,temp_show_D(:,2),'ro')
plot(TimeDebt_SimuResult.myTheta,temp_show_T(:,2),'bx')
legend('DelverDebt','TimeDebt')
xlabel('\theta')
title('coefficient of variance for S2')