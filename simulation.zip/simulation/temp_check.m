Z=reshape(target_policy,(Thres1+1)*(Thres2+1),1);
clear L;
L=SIT_f_MyPTMgen(Z,[Thres1 Thres2],[q1 q2],myTheta);
[Phi_current,Alpha_current]=eigs(L,1,'LM');
Phi_current=Phi_current./Phi_current(end);
Alpha_current,
check_RM=reshape(Phi_current,Thres1+1,Thres2+1);