% use function SIT_f_DPnum.m and SIT_f_simu.m
% to simulate 
%% input
clear all;close all;clc
q1=0.4;  %faling prob for user1
q2=0.4;   %faling prob for user2
myTheta=0.1; %risk-aversion parameter

T=1e6;     %number of total time slot
myEpsilon=1e-10; %small value to check equality for double class (relatvie difference)
T_simu=1e6;
%% prepare for randomness
rng('shuffle');
s_rSeedRecord=rng;

%% prepare for the figure
LW=1.5;MS=12;
figure;hold on;
	box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
	ylabel('E[S^{(1)}]','FontName', 'Arial')
	xlabel('\pi_1/\pi_2','FontName', 'Arial')
%% loops
% try1
    % myRatio=0.1:0.1:10;        
    % Thres1=randi([1 min(20, ceil(myRatio*20))]);
    % Thres2=max(ceil(Thres1/myRatio-0.5),1); 
% try2
Thres1=10;
for n=1:4
    for Thres2=1:40   
            [target_policy, target_Lambda, target_RM,target_accuracy]=SIT_f_DPnum(Thres1,Thres2,q1,q2,myTheta,T,myEpsilon);
            if target_accuracy==-1
                continue;
            end
            [mean_S,Positive_S,SquareP_S,RiskCost]=SIT_f_simu(Thres1,Thres2,q1,q2,myTheta,target_policy, T_simu);
            plot((Thres1+0.0)/Thres2,mean_S(1),'bx','LineWidth',LW,'MarkerSize',MS)                
    end   
    n,
end
