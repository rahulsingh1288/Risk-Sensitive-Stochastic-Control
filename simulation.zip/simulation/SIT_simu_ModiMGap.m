% function for simulation with the optimal policy to get throughput
function [mean_S,Square_S,Exp_S,Positive_S,SquareP_S,ExpP_S,Exp_C,Lambda_simu]=SIT_simu_ModiMGap(User_number,qSet,Thres_state,myTheta,T_simu)
%% input
% clear all;close all;clc
% User_number=2;
% qSet=[0.6,0.4];
% Thres_state=[3,4];
% myTheta=0.1; %risk-aversion parameter
% T_simu=1e6;

% !!! we assume \tau1<\tau2 here


%% initialization
Thres=Thres_state;
current_state=zeros(1,User_number);
n=zeros(1,User_number);
%-output
%mean_S; % get by T_simu./n
Square_S=zeros(1,User_number);
Exp_S=zeros(1,User_number);
Positive_S=zeros(1,User_number);
SquareP_S=zeros(1,User_number);
ExpP_S=zeros(1,User_number);%average exp(\theta (S-Pi)^+)
Exp_C=0;
%Lambda_simu;
%-prepare for randomness
rng('shuffle');
s_rSeedRecord=rng;
%-intermediate variables
r=exp(myTheta);
% policy_index t u 
% current_q 
%tC; %cost for current state
%tP_SI; %penalty for exceeded sensing interval, when success
%t_SI; %sensing interval
%% simulation loops
for t=1:T_simu
    % find current policy 
    policy_index=min(current_state,Thres_state);
    u=2;
    if Thres_state(1)-policy_index(1) < Thres_state(2)-policy_index(2)
        u=1;
        if policy_index(2)==(Thres_state(2)-Thres_state(1)) && policy_index(1)==0 
            u=2;
        end
    end
    % update Exp_C
    tC=sum(policy_index==Thres);
    Exp_C=Exp_C*((t-1)/t)+r^tC/t;   
    % try transmission, update state & records
    current_q=qSet(u);
    if rand(1)<current_q
        current_state=current_state+1;
    else
        current_state=current_state+1;
        % update ..._S
        t_SI=current_state(u);
        Square_S(u)=t_SI^2/(n(u)+1)+Square_S(u)*(n(u)/(n(u)+1));
        Exp_S(u)=r^t_SI/(n(u)+1)+Exp_S(u)*(n(u)/(n(u)+1));
        % update ...P_S and n
        tP_SI=max(current_state(u)-Thres_state(u),0);        
        Positive_S(u)=tP_SI/(n(u)+1)+Positive_S(u)*n(u)/(n(u)+1);
        SquareP_S(u)=tP_SI^2/(n(u)+1)+SquareP_S(u)*n(u)/(n(u)+1);    
        ExpP_S(u)=r^tP_SI/(n(u)+1)+ExpP_S(u)*(n(u)/(n(u)+1));        
        n(u)=n(u)+1;
        current_state(u)=0;        
    end
end
mean_S=T_simu./n;
Lambda_simu=log(Exp_C)/myTheta;




