% follow SIT_effectTheta_DataGen.m 
% show how the factors change along with theta
%% input
clear all;close all;clc
load Theta_Data;

%% figures- average Positive_S vs Theta
% total positive_S
% LW=1.5;MS=8;
% figure;hold on;
% box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
% ylabel('E[S_1^+]+E[S_2^+]','FontName', 'Arial')
% xlabel('Theta','FontName', 'Arial')
% title('total average interval penalty')
% 
% for n_iter=1:1
%     plot(myData{n_iter}.myTheta,sum(myData{n_iter}.Positive_S,2),'bx','LineWidth',LW,'MarkerSize',MS)
% end
%% figure- Positive_S vs VarP_S
% positive_S(1) vs VarP_S(1)
Begin_iter=1;
Stop_iter=5;

LW=1.5;MS=8;
figure;hold on; 
subplot(2,1,1); hold on;
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('E[S_1^+]','FontName', 'Arial')
xlabel('Theta','FontName', 'Arial')

for n_iter=Begin_iter:Stop_iter
    plot(myData{n_iter}.myTheta,myData{n_iter}.Positive_S(:,1),'bx','LineWidth',LW,'MarkerSize',MS)
end
subplot(2,1,2); hold on;
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('\sigma^2/\mu^2','FontName', 'Arial')
xlabel('Theta','FontName', 'Arial')

for n_iter=Begin_iter:Stop_iter
    plot(myData{n_iter}.myTheta,myData{n_iter}.VarP_S(:,1)./(myData{n_iter}.Positive_S(:,1)).^2,'ko','LineWidth',LW,'MarkerSize',MS)
end

%% figure- analytical risk with practical
Begin_iter=1;
Stop_iter=count;


LW=1.5;MS=8;
figure;hold on;
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('\Lambda','FontName', 'Arial')
xlabel('Theta','FontName', 'Arial')
title('Optimal Cost')

fg_A{1}='analytical';
fg_h(1)=plot(Set_myTheta,Set_Lambda,'b-','LineWidth',LW,'MarkerSize',MS);

fg_A{2}='practical';

    

for n_iter=Begin_iter:Stop_iter
    temp_P=(myData{n_iter}.Positive_S(:,1)+myData{n_iter}.myTheta.*myData{n_iter}.VarP_S(:,1))./myData{n_iter}.mean_S(:,1);
    temp_P=temp_P+(myData{n_iter}.Positive_S(:,2)+myData{n_iter}.myTheta.*myData{n_iter}.VarP_S(:,2))./myData{n_iter}.mean_S(:,2);
    fg_h(2)=plot(myData{n_iter}.myTheta,temp_P,'kx','LineWidth',LW,'MarkerSize',MS);
end
legend(fg_h,fg_A)





