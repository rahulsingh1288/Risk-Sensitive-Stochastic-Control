clear all;close all;clc
Thres1=30; %denote for \pi1
Thres2=30; %denote for \pi2
q1=0.8;  %faling prob for user1
q2=0.5;   %faling prob for user2
myTheta=0.001;
SIT_DPnum;
target_policy0=target_policy
for myTheta=[0.002:0.001:0.6]
  
    SIT_DPnum;
    if sum(sum(target_policy0~=target_policy))
        temp_print=['theta effect for theta=' num2str(myTheta) ' for terms' num2str(sum(sum(target_policy0~=target_policy)))],
    end
end
