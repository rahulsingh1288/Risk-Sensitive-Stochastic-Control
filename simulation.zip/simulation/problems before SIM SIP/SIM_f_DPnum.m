% function for DPnum to get optimal policy
% salute SIM_DPnum.m
function [target_policy, target_optCost, target_RM,target_accuracy]=SIM_f_DPnum(Thres1,Thres2,q1,q2,myTheta,N,myEpsilon)
%% initialization
r=exp(myTheta);
if q1*r^2>=1||q2*r^2>=1
    error('myerror: stable condition is unsatisfied')
end
V_current=zeros(Thres1+1,Thres2+1)+0.0;% denote for V(t1,t2,n)
V_past=ones(Thres1+1,Thres2+1)+0.0;%denote for V(t1,t2,n-1)
Z_current=zeros(Thres1+1,Thres2+1);%denote for Z(t1,t2,n) the opt control, i for useri, 3 for both
Z_past=zeros(Thres1+1,Thres2+1);%denote for Z(t1,t2,n-1), record to get stop condition
V_record=zeros(N,1)+0.0; % (E[X]+\theta Var[X])/n, where X is the sum of the positive cost
sys_flag=0;%indicator for iteration termination (in fact, we continue after stop to get final V_record)
N_stop=N;%number for iteration termination (as above)
N_PolicyChange=0;%number for last policy change, when matrix z(n)~=z(n-1)
RM_rgap=ones(N,1)+0.0; % the relative gap between the relative value matrixs, i.e. [RM(n)-RM(n-1)]/[RM(n)-1]
% output
target_optCost=0; % stable (E[X]+\theta Var[X])/n
target_policy=zeros(Thres1+1,Thres2+1);
target_RM=ones(Thres1+1,Thres2+1)+0.0; %relative matrix function

%% Iteration
for n=1:N
    for k1=0:Thres1
        for k2=0:Thres2       % consider V(Thres1-k1,Thres2-k2,n) in the inner loop, note matrix begin with (0,0)
            % Recursive Block, to get tVi, i.e. V under certain choice
            if k1==0 && k2==0
                t1_success=V_past(1,Thres2+1);
                t2_success=V_past(Thres1+1,1);
                tV1=(1-q1)*r^2/(1-q1*r^2)*t1_success;
                tV2=(1-q2)*r^2/(1-q2*r^2)*t2_success;
            else
                tf1=(k1==0);tf2=(k2==0);
                t_fail=r^(tf1+tf2)*V_current(Thres1-k1+2-tf1,Thres2-k2+2-tf2);
                t1_success=r^(tf1+tf2)*V_past(1,Thres2-k2+2-tf2);
                t2_success=r^(tf1+tf2)*V_past(Thres1-k1+2-tf1,1);
                tV1=q1*t_fail+(1-q1)*t1_success;
                tV2=q2*t_fail+(1-q2)*t2_success;
            end
            % Assignment Block
            V_current(Thres1-k1+1,Thres2-k2+1)=min(tV1,tV2);
            if tV1<=tV2
                Z_current(Thres1-k1+1,Thres2-k2+1)=1;
            else 
                    Z_current(Thres1-k1+1,Thres2-k2+1)=2;
            end            
        end
    end
    % Record Block 
    V_record(n)=log(V_current(1,1))./myTheta;
    V_current=V_current./V_current(1,1);
    temp_rgapM=(V_current-V_past)./(V_current-1+(V_current==1));
    RM_rgap(n)=max(max(abs(temp_rgapM)));
    % Stable Output
    if RM_rgap(n)<myEpsilon  % record optimal policy and...
        sys_flag=1;N_stop=n;       
        target_optCost=V_record(N_stop);
        target_policy=Z_current;
        target_RM=V_current;
        target_accuracy=RM_rgap(N_stop);
        temp_print=['gap=' num2str(target_accuracy)],
        break;
    end    
    if sum(sum(Z_current~=Z_past))
        N_PolicyChange=n;
    end
    % prepare for next stage
    V_past=V_current;
    Z_past=Z_current;
    V_current=zeros(size(V_current))+0.0;
    Z_current=zeros(size(Z_current))+0.0;            
end

%% connect to next program
if sys_flag==0
    if RM_rgap(N)<=myEpsilon*10 || N-N_PolicyChange>1e4
        sys_flag=1;N_stop=N;       
        target_optCost=V_record(N_stop);
        target_policy=Z_past;
        target_RM=V_past;    
        target_accuracy=RM_rgap(N_stop);
        temp_print=['acceptable termination at Pi1=' int2str(Thres1) ' Pi2=' int2str(Thres2) ' gap=' num2str(target_accuracy) ' N_PolicyChange' num2str(log(N_PolicyChange)/log(10))],
    else
        if N>=1e7
            N_stop=N;       
            target_optCost=V_record(N_stop);
            target_policy=Z_past;
            target_RM=V_past;    
            target_accuracy=RM_rgap(N_stop);
            temp_print=['fail it !!! at Pi1=' int2str(Thres1) ' Pi2=' int2str(Thres2) ' gap=' num2str(target_accuracy) ' N_PolicyChange' num2str(log(N_PolicyChange)/log(10))],
        else
        temp_print=['extention for Pi1=' int2str(Thres1) ' Pi2=' int2str(Thres2) ' N=10^' num2str(log(N)/log(10)) ' Epsilon=10^' num2str(log(myEpsilon)/log(10)) ' gap=' num2str(RM_rgap(N)) ' N_PolicyChange' int2str(log10(N_PolicyChange))],
        clear V_current V_past Z_current Z_past;
        clear i j k1 k2 n;
        clear t1_success t2_success tV1 tV2 t_fail tf1 tf2;
        clear tt;
        clear temp_PrGap temp_rGapM;
        [target_policy, target_optCost, target_RM,target_accuracy]=SIM_f_DPnum(Thres1,Thres2,q1,q2,myTheta,N*10,min(myEpsilon*10,1e-2));
        end
    end
end
