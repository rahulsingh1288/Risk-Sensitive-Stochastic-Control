% DP algorithm Iteration for the group n1=0,n2=1
syms r q;
V{1}=(r*(q - 1))/(q*r - 1);
for i=2:5
    V{i}=q*(V{i-1})+1-q;
    V{i}=simple(V{i});
    V{i}=simple(V{i});
    i-1,pretty(V{i}),
end

