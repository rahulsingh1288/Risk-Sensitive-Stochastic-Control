% follow SIM_MainShow.m
% prepare for the figures;
LW=1.5;MS=12;
fg_label=['b->' 'k-s' 'm-o' 'r-*'];

figure;hold on;
subplot(2,1,1);hold on; % delete this one without subplot
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('Throughput for User 1','FontName', 'Arial')
xlabel('\pi_2','FontName', 'Arial')
fg_h=zeros(1,n_ShowCase)
    for j=1:n_ShowCase-1
        fg_A{j}=['\pi_1=' int2str(ShowCase_Thres1{j})];
        fg_h(j)=plot(ShowCase_SetThres2{j}, ShowCase_Rate1{j},fg_label(3*(j-1)+1:3*(j-1)+3),'LineWidth',LW,'MarkerSize',MS);
        
    end
    legend(fg_h,fg_A);
    
subplot(2,1,2);hold on; % delete this one without subplot
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('Throughput for User 2','FontName', 'Arial')
xlabel('\pi_2','FontName', 'Arial')
    for j=1:n_ShowCase-1
        fg_A{j}=['\pi_1=' int2str(ShowCase_Thres1{j})];
        fg_h(j)=plot(ShowCase_SetThres2{j}, ShowCase_Rate2{j},fg_label(3*(j-1)+1:3*(j-1)+3),'LineWidth',LW,'MarkerSize',MS);
    end
    legend(fg_h,fg_A);
    
figure;hold on; 
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('Total Throughput','FontName', 'Arial')
xlabel('\pi_2','FontName', 'Arial')
    for j=1:n_ShowCase-1
        fg_A{j}=['\pi_1=' int2str(ShowCase_Thres1{j})];
        fg_h(j)=plot(ShowCase_SetThres2{j}, ShowCase_Rate{j},fg_label(3*(j-1)+1:3*(j-1)+3),'LineWidth',LW,'MarkerSize',MS);
    end
    legend(fg_h,fg_A);   
    
    
figure;hold on;
box on;set(gca,'LineWidth',1,'FontName', 'Arial', 'FontSize',16,'TickLength',[0.020 0.025]);
ylabel('Relative Throughput user1','FontName', 'Arial')
xlabel('\pi_2/\pi_1','FontName', 'Arial')

    for j=1:n_ShowCase-1
        fg_A{j}=['base on\pi_1=' int2str(ShowCase_Thres1{j})];
        fg_h(j)=plot(ShowCase_SetThres2{j}./ShowCase_Thres1{j}, ShowCase_Rate1{j}./ShowCase_Rate{j},fg_label(3*(j-1)+1:3*(j-1)+3),'LineWidth',LW,'MarkerSize',MS);
    end
    legend(fg_h,fg_A);  

