syms r q;
v0=(1+(r^2-1)/(1-q*r^2))*(1+(r-1)/(1-q*r));
v0=simple(v0);v0=simple(v0);
temp_show=0,pretty(v0),
v{1}=q*r*v0+(1-q)*r*(1+(r-1)/(1-q*r));
v{1}=simple(v{1});
temp_show=1,pretty(v{1}),
for k=1:5
    v{k+1}=q*r*v{k}+(1-q)*r*(1+q^k*(r-1)/(1-q*r));
    v{k+1}=simple(v{k+1});v{k+1}=factor(v{k+1});
    temp_show=k+1,pretty(v{k+1}),
end

