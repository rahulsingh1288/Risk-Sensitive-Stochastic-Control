% V(\pi-k,\pi-k,1,1)
syms q r;
v{1}=(1-q)^2*r^3/(1-q*r^2)/(1-q*r);
for k=1:7
    v{k+1}=q*v{k}+(1-q)*(1+q^k*(r-1)/(1-q*r));
    v{k+1}=simple(v{k+1});v{k+1}=factor(v{k+1});
    temp_show=k,pretty(v{k+1}),
end
