% show the throughput as a function of threshold requirements
%% input
% clear all;close all;clc;n_ShowCase=1;
% input for SIM_DPnum
Thres1=12; %denote for \pi1
%Thres2=8; %denote for \pi2
q1=0.05;  %faling prob for user1
q2=0.05;   %faling prob for user2
myTheta=0.02; %risk-aversion parameter
N=1e6;     %number of total stage
myEpsilon=1e-6; %small value to check equality for double class (relatvie difference)
% input for SIM_simu
N_simu=1e6;%total transmission times
Dist_Bound=2; % relative upper bound for distribution array
% input for this show
Set_Thres2=[1:12];

%% initialization
N_show=length(Set_Thres2);
% output
show_Rate1=zeros(N_show,1);
show_Rate2=zeros(N_show,1);
show_Rate=zeros(N_show,1);
%% find the throughput
for Thres2=Set_Thres2
    Thres2,
    [target_policy, target_optCost, target_RM,target_accuracy]=SIM_f_DPnum(Thres1,Thres2,q1,q2,myTheta,N,myEpsilon);
    [myR_all,myR_1,myR_2,simu_optCost]=SIM_f_simu(Thres1,Thres2,q1,q2,myTheta,target_policy, N_simu,Dist_Bound);
    show_Rate1(Set_Thres2==Thres2)=myR_1;
    show_Rate2(Set_Thres2==Thres2)=myR_2;
    show_Rate(Set_Thres2==Thres2)=myR_all;
end

%% record
ShowCase_Rate1{n_ShowCase}=show_Rate1;
ShowCase_Rate2{n_ShowCase}=show_Rate2;
ShowCase_Rate{n_ShowCase}=show_Rate;
ShowCase_Thres1{n_ShowCase}=Thres1;
ShowCase_SetThres2{n_ShowCase}=Set_Thres2;
n_ShowCase=n_ShowCase+1;

