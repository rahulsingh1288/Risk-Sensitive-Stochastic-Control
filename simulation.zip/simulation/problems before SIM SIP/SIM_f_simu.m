% function for simulation with the optimal policy to get throughput
% salute SIM_simu.m
function [myR_all,myR_1,myR_2,simu_optCost]=SIM_f_simu(Thres1,Thres2,q1,q2,myTheta,target_policy, N_simu,Dist_Bound)
%% initialization
state_t1=0; %system state(t1,t2)
state_t2=0; % system state (t1,t2)
T=0; %time slot, to calculate throughput
n=0; %count total successful transmission
n1=0; %count total success for user 1
n2=0; %count total success for user 2
% output
Dist_State=0.0+zeros(Thres1+1,Thres2+1); % state distribution, wrt T
Dist_T=0.0+zeros(1,Dist_Bound*Thres1);% transition time distribution for user 1, wrt N
Dist_S=0.0+zeros(1,Dist_Bound*Thres2);% transition time distribution for user 2, wrt N
myCost=0.0;% total cost, i.e. log(E[exp(...)])/N, wrt N
% prepare for randomness
rng('shuffle');
s_rSeedRecord=rng;
% others
r=exp(myTheta);
if q1*r^2>=1||q2*r^2>=1
    error('myerror: stable condition is unsatisfied')
end
r_log=log(r);


%% simulation loops
while n<N_simu
    % find current policy z, update Dist_state
    policy_t1=min(state_t1,Thres1)+1;
    policy_t2=min(state_t2,Thres2)+1;
    Dist_State=Dist_State.*(T/(T+1.0));
    Dist_State(policy_t1,policy_t2)=Dist_State(policy_t1,policy_t2)+1/(T+1.0);
    z=target_policy(policy_t1,policy_t2);
    % try transmission, update state & cost & statistics
    switch z
        case 1
            if rand(1)<q1 %fail the transmission
                state_t1=state_t1+1;
                state_t2=state_t2+1;
            else                
                myCost=myCost*(n/(n+1.0))+max(state_t1+1-Thres1,0)*r_log/(n+1);                
                Dist_T=Dist_T.*(n/(n+1.0));
                Dist_S=Dist_S.*(n/(n+1.0));
                Dist_T(min(state_t1+1,Dist_Bound*Thres1))=Dist_T(min(state_t1+1,Dist_Bound*Thres1))+1/(n+1.0);                         
                n=n+1;
                n1=n1+1;
                state_t1=0;
                state_t2=state_t2+1;
            end
        case 2
            if rand(1)<q2 %fail the transmission
                state_t1=state_t1+1;
                state_t2=state_t2+1;
            else
                myCost=myCost*(n/(n+1.0))+max(state_t2+1-Thres2,0)*r_log/(n+1);
                Dist_T=Dist_T.*(n/(n+1.0));
                Dist_S=Dist_S.*(n/(n+1.0));
                Dist_S(min(state_t2+1,Dist_Bound*Thres2))=Dist_S(min(state_t2+1,Dist_Bound*Thres2))+1/(n+1.0);
                n=n+1;
                n2=n2+1;
                state_t2=0;
                state_t1=state_t1+1;                
            end
        otherwise
            error('myError: wrong currrent policy z');
    end
    % iteration for next loop        
    T=T+1;   
end

%% Manipulate and Demonstration
%consistance for cost 
simu_optCost=myCost/myTheta;
%calculate throughput
myR_all=n/T;
myR_1=n1/T;
myR_2=n2/T;



