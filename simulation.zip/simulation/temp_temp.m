%% input
clear all;close all;clc;
User_number=2;
Thres=[6,3];
q=[0.10,0.10];
myTheta=0.01;
T=1e6;
myEpsilon=1e-10;
%% compute
[target_policy, target_Lambda, target_RM,target_accuracy]=SIT_num_ValueIter(q,Thres,myTheta,T,myEpsilon);
target_policy,
