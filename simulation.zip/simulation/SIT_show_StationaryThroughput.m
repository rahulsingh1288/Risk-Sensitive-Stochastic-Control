clear all;close all;
load Policy_Compare
Throughput_Estimate=(1./Thres)./sum(1./Thres);
temp_show=1./Station_SimuResult.mean_S;%---temp_show(:,1) throughput column for user 1

figure;subplot(1,2,1);hold on;
title('normalized throughput for user 1')
plot(Set_myTheta,Throughput_Estimate(1).*ones(size(Set_myTheta)),'k-');
plot(Set_myTheta,temp_show(:,1)./(1-q(1)),'bx');
legend('estimate','simulation')

subplot(1,2,2);hold on;
title('normalized throughput for user 2')
plot(Set_myTheta,Throughput_Estimate(2).*ones(size(Set_myTheta)),'k-');
plot(Set_myTheta,temp_show(:,2)./(1-q(2)),'bx');
legend('estimate','simulation')


