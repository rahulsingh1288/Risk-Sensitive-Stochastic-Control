% check all the switching policy to get the optimal one
function [Ratio_opt,Lambda_opt,Alpha_opt]=SIT_num_SwitchPolicy(q,Thres,myTheta)
%% input
% clear all;close all;
% Thres=[30,30];
% q=[0.8,0.5];
% myTheta=0.001; %risk-aversion parameter
% Delta_ratio=0.1; %what is the tolerable error of the ratio
%% initialization
%-output
Alpha_opt=-1; % optimal alpha (eigenvalue)
%Lambda_opt;
Ratio_opt=0; % optimal ratio compare (K2*Ratio, K1), choose the larger one
%-prepare
SetRatio=[0.5/Thres(2):0.1:Thres(1)/0.5];
%-other intermediate variables
tN=(Thres(1)+1)*(Thres(2)+1);
tK=zeros(1,2);
%L; %the transition probability matrix
%tRatio; %temp ratio
%tAlpha; %temp allpha
%tX;tZ;tq;tPhi;
%% body
for tRatio=SetRatio
    L=zeros(tN,tN);
    for tX=1:tN
        tK(2)=floor((tX-1)/(Thres(1)+1));
        tK(1)=tX-1-tK(2)*(Thres(1)+1);
        tZ=1;
        if tK(2)*tRatio/Thres(2)>tK(1)/Thres(1)
            tZ=2;
        end        
        tq=q(tZ);
        tCost=sum(tK==Thres);
        % for the fail state;
        tK_fail=min(tK+1,Thres);
        tX_fail=tK_fail*[1;Thres(1)+1]+1;
        L(tX,tX_fail)=tq*exp(myTheta*tCost); % probability * exp(\theta*l(x))
        % for the success state;
        tK_success=tK_fail;
        tK_success(tZ)=0;
        tX_success=tK_success*[1;Thres(1)+1]+1;
        L(tX,tX_success)=(1-tq)*exp(myTheta*tCost);    
    end
    % record and update result
    [tPhi,tAlpha]=eigs(L,1,'LM');
    if (~(tAlpha>0))
        error('myError: wrong eigenvalue/vector');
    end
    if tAlpha<Alpha_opt ||Alpha_opt==-1
        Alpha_opt=tAlpha;
        Ratio_opt=tRatio;
    end
end
Lambda_opt=log(Alpha_opt)/myTheta;
%% demonstrate
% Alpha_opt,
% Lambda_opt,
% Ratio_opt,
% [target_policy, target_Lambda, target_RM,target_accuracy]=SIT_f_DPnum(Thres(1),Thres(2),q(1),q(2),myTheta,1e6,1e-10);
% Gap_Ratio=log(Alpha_opt)/myTheta/target_Lambda,
% rGap=Gap_Ratio-1,

