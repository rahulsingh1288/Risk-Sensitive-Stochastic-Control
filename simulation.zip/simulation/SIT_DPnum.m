% function for DPnum to get optimal policy- use value iteration
% salute SIM_DPnum.m
%function [target_policy, target_optCost, target_RM,target_accuracy]=SIT_f_DPnum(Thres1,Thres2,q1,q2,myTheta,T,myEpsilon)
%% input
clear all;close all;
Thres1=6; 
Thres2=10; 
q1=0.1;%faling
q2=q1;
myTheta=0.3; 
%risk-aversion parameter
T=1e6;     %number of total time slot
myEpsilon=1e-10; %small value to check equality for double class (relatvie difference)


%% initialization
r=exp(myTheta);
if q1*r^2>=1||q2*r^2>=1
    temp_show='myerror: stable condition for q & myTheta is unsatisfied'
end
V_current=ones(Thres1+1,Thres2+1)+0.0;% denote for V(k1,k2,t)
V_past=ones(Thres1+1,Thres2+1)+0.0;%denote for V(k1,k2,t-1)
Z_current=zeros(Thres1+1,Thres2+1);%denote for Z(k1,k2,t) the opt control, i for useri, 3 for both
Z_past=zeros(Thres1+1,Thres2+1);%denote for Z(k1,k2,t-1), record to get stop condition
sys_flag=0;%indicator for iteration termination 
T_stop=T;%time slot for iteration termination (as above)
T_PolicyChange=0;%number for last policy change, when matrix z(n)~=z(n-1)
% output
target_alpha=0; % stable multiplexer, i.e. V(Thres1,Thres2,t)/V(Thres1,Thres2,t-1) 
target_policy=zeros(Thres1+1,Thres2+1);
target_RM=ones(Thres1+1,Thres2+1)+0.0; %relative matrix function
target_accuracy=1; % stopping relative RM_rgap
% other intermediated variables
% t_Multiplexer t_fail_k1 t_fail_k2 tV1 tV2
% temp_alpha temp_rgapM
% temp_print
%% Iteration
for t=1:T
    for k1=0:Thres1
        for k2=0:Thres2       % consider V(k1,k2,t) in the inner loop, note matrix begin with (0,0)
            % Recursive Block, to get tVi, i.e. V under certain choice
            t_Multiplexer=r^(max(k1-Thres1+1,0)+max(k2-Thres2+1,0));
            t_fail_k1=min(k1+1,Thres1);
            t_fail_k2=min(k2+1,Thres2);
            tV1=q1*V_past(t_fail_k1+1,t_fail_k2+1)+(1-q1)*V_past(1,t_fail_k2+1);
            tV2=q2*V_past(t_fail_k1+1,t_fail_k2+1)+(1-q2)*V_past(t_fail_k1+1,1);  
            % Assignment Block
            V_current(k1+1,k2+1)=t_Multiplexer*min(tV1,tV2);
            if tV1<tV2
                Z_current(k1+1,k2+1)=1;
            else 
                    Z_current(k1+1,k2+1)=2;
            end            
        end
    end
    % Record Block 
%     temp_show=t,
%     Z_current,
    temp_alpha=V_current(Thres1+1,Thres2+1);
    V_current=V_current./V_current(Thres1+1,Thres2+1);
    temp_rgapM=(V_current-V_past)./V_current;
    RM_rgap=max(max(abs(temp_rgapM)));
    % Stable Output
    if RM_rgap<myEpsilon && sys_flag==0  % record optimal policy and...
        sys_flag=1;T_stop=t;       
        target_alpha=temp_alpha;
        target_policy=Z_current;
        target_RM=V_current;
        target_accuracy=RM_rgap;
%         temp_print=['DPnum-got it, Pi1=' int2str(Thres1) ' Pi2=' int2str(Thres2) ' T_stop=' num2str(T_stop) ' T_PolicyChange=' num2str(T_PolicyChange) ' gap=10^' num2str(log10(target_accuracy))],
    end    
    if t>2*T_stop && sys_flag
        break;
    end
    if sum(sum(Z_current~=Z_past))
        T_PolicyChange=t;
    end
    % prepare for next stage
    V_past=V_current;
    Z_past=Z_current;
    V_current=zeros(size(V_current))+0.0;
    Z_current=zeros(size(Z_current));
    % enlarge the recorders if donot stop
    if sys_flag==0 && t==T
        temp_print=['extention for Pi1=' int2str(Thres1) ' Pi2=' int2str(Thres2) ' T=' num2str(T) ' Epsilon=' num2str(myEpsilon) ' gap=' num2str(RM_rgap(T)) ' T_PolicyChange' num2str(T_PolicyChange)],
        T=2*T;
        T_stop=T;  
    end
end

% check
if sum(sum(Z_current~=target_policy))&& T_PolicyChange>T_stop
    temp_show='myerror: fake stable'
end
target_policy
%target_RM

