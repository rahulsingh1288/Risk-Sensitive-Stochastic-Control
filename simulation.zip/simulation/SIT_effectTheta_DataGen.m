% follow SIT_effectTheta_PolicyGen.m; use SIT_f_DPnum.m SIT_f_simu.m
% show the effect of theta, to generate simulation results
%% input
clear all;close all;clc;
load Theta_Policy
count=0;
T_simu=1e7;
User_number=2;

%% boundy
for n_iter=1:5
    count=count+1;
    % initialization
    myData{count}=struct('myTheta',Set_myTheta,'mean_S',zeros(ThetaSet_Length,User_number),'Positive_S',zeros(ThetaSet_Length,User_number),'VarP_S',zeros(ThetaSet_Length,User_number),'RiskCost',zeros(ThetaSet_Length,1));
       
    for i_iter=1:ThetaSet_Length
        % get parameter from the policy sets
        target_policy=Set_Policy(:,:,i_iter);
        myTheta=Set_myTheta(i_iter);
        % simulation
        [mean_S,Positive_S,SquareP_S,RiskCost]=SIT_f_simu(Thres1,Thres2,q1,q2,myTheta,target_policy, T_simu);
        VarP_S=SquareP_S-Positive_S.^2;
        % record into the structure
         myData{count}.myTheta(i_iter)=myTheta;
         myData{count}.mean_S(i_iter,:)=mean_S;
         myData{count}.Positive_S(i_iter,:)=Positive_S;
         myData{count}.VarP_S(i_iter,:)=VarP_S;
         myData{count}.RiskCost(i_iter)=RiskCost;        
    end
    n_iter,
end
clear mean_S Positive_S SquareP_S RiskCost VarP_S;
clear i_iter n_iter;
clear myTheta target_policy;


save Theta_Data