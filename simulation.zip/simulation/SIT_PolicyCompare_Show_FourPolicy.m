clear all;close all;clc
load Policy_Compare

figure;hold on;
temp_show=(Station_SimuResult.Positive_S+[Station_SimuResult.myTheta,Station_SimuResult.myTheta].*(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2))./Station_SimuResult.mean_S;
plot(Station_SimuResult.myTheta,sum(temp_show,2),'b-');
temp_show=(DeliverDebt_SimuResult.Positive_S+[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
plot(DeliverDebt_SimuResult.myTheta,sum(temp_show,2),'rs');
% temp_show=(TimeDebt_SimuResult.Positive_S+[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
% plot(TimeDebt_SimuResult.myTheta,sum(temp_show,2),'k.');
temp_show=(PackageRR_SimuResult.Positive_S+[PackageRR_SimuResult.myTheta,PackageRR_SimuResult.myTheta].*(PackageRR_SimuResult.SquareP_S-(PackageRR_SimuResult.Positive_S).^2))./PackageRR_SimuResult.mean_S;
plot(PackageRR_SimuResult.myTheta,sum(temp_show,2),'go');
% temp_show=(RoundRobin_SimuResult.Positive_S+[RoundRobin_SimuResult.myTheta,RoundRobin_SimuResult.myTheta].*(RoundRobin_SimuResult.SquareP_S-(RoundRobin_SimuResult.Positive_S).^2))./RoundRobin_SimuResult.mean_S;
% plot(RoundRobin_SimuResult.myTheta,sum(temp_show,2),'bd');


% legend('Ours', 'DD','TD','PRR','RR')
legend('Ours','DD','PRR')
title('Physical \theta-sensitive cost')

% figure;hold on;
% subplot(1,2,1);hold on;
% temp_show=(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2)./Station_SimuResult.Positive_S.^2;
% plot(Station_SimuResult.myTheta,temp_show(:,1),'ko');
% temp_show=(Switch_SimuResult.SquareP_S-(Switch_SimuResult.Positive_S).^2)./Switch_SimuResult.Positive_S.^2;
% plot(Switch_SimuResult.myTheta,temp_show(:,1),'b.');
% title('c_p^2 for user 1')
% legend('opt','Switch')
% subplot(1,2,2);hold on;
% temp_show=(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2)./Station_SimuResult.Positive_S.^2;
% plot(Station_SimuResult.myTheta,temp_show(:,2),'ko');
% temp_show=(Switch_SimuResult.SquareP_S-(Switch_SimuResult.Positive_S).^2)./Switch_SimuResult.Positive_S.^2;
% plot(Switch_SimuResult.myTheta,temp_show(:,2),'b.');
% title('c_p^2 for user 2')
% legend('opt','Switch')
% 
% 
% figure;hold on;
% subplot(1,2,1);hold on;
% temp_show=(Station_SimuResult.Square_S-(Station_SimuResult.mean_S).^2)./Station_SimuResult.mean_S.^2;
% plot(Station_SimuResult.myTheta,temp_show(:,1),'ko');
% temp_show=(Switch_SimuResult.Square_S-(Switch_SimuResult.mean_S).^2)./Switch_SimuResult.mean_S.^2;
% plot(Switch_SimuResult.myTheta,temp_show(:,1),'b.');
% title('c_s^2 for user 1')
% legend('opt','Switch')
% subplot(1,2,2);hold on;
% temp_show=(Station_SimuResult.Square_S-(Station_SimuResult.mean_S).^2)./Station_SimuResult.mean_S.^2;
% plot(Station_SimuResult.myTheta,temp_show(:,2),'ko');
% temp_show=(Switch_SimuResult.Square_S-(Switch_SimuResult.mean_S).^2)./Switch_SimuResult.mean_S.^2;
% plot(Switch_SimuResult.myTheta,temp_show(:,2),'b.');
% title('c_s^2 for user 2')
% legend('opt','Switch')
% 
