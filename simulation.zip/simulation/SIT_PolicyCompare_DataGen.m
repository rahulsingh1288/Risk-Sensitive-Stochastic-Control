% this file is to generate analysis&simulation results for Policies
%   Stationary, Delivery-Debt, Time-Debt, Round-Robin, Package-level Round Robin
%% input
clear all;close all;clc;
User_number=2;
Thres=[20,15];
q=[0.90,0.90];
T=1e6;
myEpsilon=1e-10;
T_simu=1e6;
Set_myTheta=1e-6+[0:0.003:0.03];%(-log(max(q))/User_number-3*1e-6)];
%% initialize
Set_length=length(Set_myTheta);
%-intermediate variables
%mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu
%myTheta, i_iter
% save('Policy_Compare')
%% Staionary policy
%temp_varibales: target_policy, target_Lambda, target_RM,target_accuracy;%for _num_ValueIter
Station_AnaResult=struct('myTheta',zeros(Set_length,1),'Station_Lambda',zeros(Set_length,1));
Station_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
    myTheta=Set_myTheta(i_iter);
    % numerical result
    [target_policy, target_Lambda, target_RM,target_accuracy]=SIT_num_ValueIter(q,Thres,myTheta,T,myEpsilon);
    Station_AnaResult.myTheta(i_iter)=myTheta;
    Station_AnaResult.Station_Lambda(i_iter)=target_Lambda;
    myTheta,
    target_policy,
    % simulation result
    [mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_StationPolicy(User_number,q,Thres,myTheta,T_simu,target_policy);
    Station_SimuResult.myTheta(i_iter)=myTheta;
    Station_SimuResult.mean_S(i_iter,:)=mean_S;
    Station_SimuResult.Square_S(i_iter,:)=Square_S;
    Station_SimuResult.Exp_S(i_iter,:)=Exp_S;
    Station_SimuResult.Positive_S(i_iter,:)=Positive_S;
    Station_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    Station_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    Station_SimuResult.Exp_C(i_iter)=Exp_C;
    Station_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','User_number','q','Thres','Set_myTheta','T', 'myEpsilon', 'T_simu','Station_AnaResult','Station_SimuResult');
clear target_policy  target_Lambda  target_RM target_accuracy;
clear Station_AnaResult Station_SimuResult;
%% Delivery Debt Policy
DeliverDebt_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
    myTheta=Set_myTheta(i_iter);
    % simulation result
    [mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S, Exp_C, Lambda_simu]=SIT_simu_DeliveryDebt(User_number,q,Thres,myTheta,T_simu);
    DeliverDebt_SimuResult.myTheta(i_iter)=myTheta;
    DeliverDebt_SimuResult.mean_S(i_iter,:)=mean_S;
    DeliverDebt_SimuResult.Square_S(i_iter,:)=Square_S;
    DeliverDebt_SimuResult.Exp_S(i_iter,:)=Exp_S;
    DeliverDebt_SimuResult.Positive_S(i_iter,:)=Positive_S;
    DeliverDebt_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    DeliverDebt_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    DeliverDebt_SimuResult.Exp_C(i_iter)=Exp_C;
    DeliverDebt_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','DeliverDebt_SimuResult','-append');
clear DeliverDebt_SimuResult;
temp_show='DD Done',
% %% Time Debt Policy
% TimeDebt_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
% for i_iter=1:Set_length
%     myTheta=Set_myTheta(i_iter);
%     % simulation result
%    	[mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_TimeDebt(User_number,q,Thres,myTheta,T_simu);
%     TimeDebt_SimuResult.myTheta(i_iter)=myTheta;
%     TimeDebt_SimuResult.mean_S(i_iter,:)=mean_S;
%     TimeDebt_SimuResult.Square_S(i_iter,:)=Square_S;
%     TimeDebt_SimuResult.Exp_S(i_iter,:)=Exp_S;
%     TimeDebt_SimuResult.Positive_S(i_iter,:)=Positive_S;
%     TimeDebt_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
%     TimeDebt_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
%     TimeDebt_SimuResult.Exp_C(i_iter)=Exp_C;
%     TimeDebt_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
% end
% save('Policy_Compare','TimeDebt_SimuResult','-append');
% clear TimeDebt_SimuResult;
% 
% clear mean_S Square_S Exp_S Positive_S SquareP_S  ExpP_S Exp_C Lambda_simu;
% clear myTheta i_iter;
% temp_show='TD Done',
% %% Round Robin Policy
% RoundRobin_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
% for i_iter=1:Set_length
%     myTheta=Set_myTheta(i_iter);
%     % simulation result
%    	[mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_RoundRobin(User_number,q,Thres,myTheta,T_simu);
%     RoundRobin_SimuResult.myTheta(i_iter)=myTheta;
%     RoundRobin_SimuResult.mean_S(i_iter,:)=mean_S;
%     RoundRobin_SimuResult.Square_S(i_iter,:)=Square_S;
%     RoundRobin_SimuResult.Exp_S(i_iter,:)=Exp_S;
%     RoundRobin_SimuResult.Positive_S(i_iter,:)=Positive_S;
%     RoundRobin_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
%     RoundRobin_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
%     RoundRobin_SimuResult.Exp_C(i_iter)=Exp_C;
%     RoundRobin_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
% end
% save('Policy_Compare','RoundRobin_SimuResult','-append');
% clear RoundRobin_SimuResult;
% 
% clear mean_S Square_S Exp_S Positive_S SquareP_S  ExpP_S Exp_C Lambda_simu;
% clear myTheta i_iter;
% temp_show='RR Done',
%% package-level Round-Robin
PackageRR_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
%     i_iter,
    myTheta=Set_myTheta(i_iter);
    % simulation result
   	[mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_PackageRR(User_number,q,Thres,myTheta,T_simu);
    PackageRR_SimuResult.myTheta(i_iter)=myTheta;
    PackageRR_SimuResult.mean_S(i_iter,:)=mean_S;
    PackageRR_SimuResult.Square_S(i_iter,:)=Square_S;
    PackageRR_SimuResult.Exp_S(i_iter,:)=Exp_S;
    PackageRR_SimuResult.Positive_S(i_iter,:)=Positive_S;
    PackageRR_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    PackageRR_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    PackageRR_SimuResult.Exp_C(i_iter)=Exp_C;
    PackageRR_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','PackageRR_SimuResult','-append');
clear PackageRR_SimuResult;

clear mean_S Square_S Exp_S Positive_S SquareP_S  ExpP_S Exp_C Lambda_simu;
clear myTheta i_iter;
temp_show='PRR Done',


