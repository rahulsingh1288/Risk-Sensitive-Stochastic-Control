% analyze the 
r=exp(0.001);
q_bound=1./r;
q=[0:q_bound/10:q_bound/2];
h=(1-q.*r)./(1-q.*r.^2);
figure;hold on;
plot(q,h,'b-')
