% function to get transition probability matrix from policy vector
function L=SIT_f_MyPTMgen(Z,Thres,q,myTheta)
% Z policy vector; Thres=[\pi_1,\pi_2];q=[q_1,q_2];
%% initialization
N=length(Z);
L=zeros(N,N);
tK=zeros(1,2);
%% assign proability for each state, and multiply the exponential cost
for tX=1:N
    tK(2)=floor((tX-1)/(Thres(1)+1));
    tK(1)=tX-1-tK(2)*(Thres(1)+1);
    tq=q(Z(tX));
    tCost=sum(tK==Thres);
    % for the fail state;
    tK_fail=min(tK+1,Thres);
    tX_fail=tK_fail*[1;Thres(1)+1]+1;
    L(tX,tX_fail)=tq*exp(myTheta*tCost); % probability * exp(\theta*l(x))
    % for the success state;
    tK_success=tK_fail;
    tK_success(Z(tX))=0;
    tX_success=tK_success*[1;Thres(1)+1]+1;
    L(tX,tX_success)=(1-tq)*exp(myTheta*tCost);    
end