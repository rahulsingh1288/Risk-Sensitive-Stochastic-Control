%simulation for a switch policy
function [mean_S, Square_S, Exp_S, Positive_S,SquareP_S,ExpP_S,Exp_C,Lambda_simu]=SIT_simu_SwitchPolicy(User_number,q,Thres,myTheta,T_simu,Ratio_opt)
%% input
% clear all;close all;
% Thres=[5,4]; %denote for [\pi_1,\pi_2]
% q=[0.6,0.4];  %faling prob for users
% myTheta=0.5; %risk-aversion parameter
% Ratio_opt=2.925; % optimal weight for K2  
% T_simu=1e6;
%     % compare (K2*Ratio, K1), choose the larger
% User_number=2;

%% initialization
%-output
%mean_S=zeros(1,User_number);%average sensing intervals
Square_S=zeros(1,User_number);
Exp_S=zeros(1,User_number);
Positive_S=zeros(1,User_number);%average exceeded sensing intervals
SquareP_S=zeros(1,User_number);%second-moment of the exceeded Sensing intervals
ExpP_S=zeros(1,User_number);%average exp(\theta (S-Pi)^+)
Exp_C=0;
%Lambda_simu;
%-intermediated variable: state related
n=zeros(1,User_number); %to count the successful transmission
Current_State=zeros(1,User_number); %system state
%-prepare for randomness
rng('shuffle');
s_rSeedRecord=rng;
%-other intermediated variables
r=exp(myTheta);
%tC; %cost for current state
tI=[1:User_number];
%tq; %temporary failing probability 
%tP_SI; %penalty for exceeded sensing interval, when success
%% body 
for t=1:T_simu   
    % choose policy
    Policy_State=min(Current_State,Thres);
    u=1;
    if Policy_State(2)*Ratio_opt/Thres(2)>Policy_State(1)/Thres(1)
        u=2;
    end
    tq=q(u);
    % update Exp_C 
    tC=sum(Policy_State==Thres);
    Exp_C=Exp_C*((t-1)/t)+r^tC/t;   
    % try transmission
    if rand(1)<tq
        Current_State=Current_State+1;
    else
        Current_State=Current_State+1;
        % update ..._S
        t_SI=Current_State(u);
        Square_S(u)=t_SI^2/(n(u)+1)+Square_S(u)*(n(u)/(n(u)+1));
        Exp_S(u)=r^t_SI/(n(u)+1)+Exp_S(u)*(n(u)/(n(u)+1));
        % update ..._S and n; %mean_S will just get by T/n
        tP_SI=max(Current_State(u)-Thres(u),0);     
        Positive_S(u)=tP_SI/(n(u)+1)+Positive_S(u)*(n(u)/(n(u)+1));
        SquareP_S(u)=tP_SI^2/(n(u)+1)+SquareP_S(u)*(n(u)/(n(u)+1));
        ExpP_S(u)=r^tP_SI/(n(u)+1)+ExpP_S(u)*(n(u)/(n(u)+1));
        n(u)=n(u)+1;
        Current_State(u)=0;   
    end
end
mean_S=T_simu./n;
Lambda_simu=log(Exp_C)/myTheta;
% Lambda_simu0=sum(log(ExpP_S)./mean_S)/myTheta; % not stable states, cannot apply x ones
% %% demonstrate
% temp_show=[mean_S;Positive_S;SquareP_S;ExpP_S],
% Lambda_simu,
% Lambda_simu0,
% Lambda_simu2=sum((Positive_S+myTheta./2.*(SquareP_S-Positive_S.^2))./mean_S),
