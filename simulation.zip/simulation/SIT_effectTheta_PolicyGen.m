% use SIT_f_DPnum.m SIT_f_simu.m
% show the effect of theta
%% input
clear all;close all;clc;
Thres1=30; %denote for \pi1
Thres2=30; %denote for \pi2
q1=0.8;  %faling prob for user1
q2=0.5;   %faling prob for user2

T=1e6;     %number of total time slot
myEpsilon=1e-10; %small value to check equality for double class (relatvie difference)

Set_myTheta=[0.001:0.01:0.111]';
%% initialize
ThetaSet_Length=length(Set_myTheta);
Set_Policy=zeros(Thres1+1,Thres2+1,ThetaSet_Length);
Set_Lambda=zeros(ThetaSet_Length,1);

%% body
for i_iter=1:ThetaSet_Length
    myTheta=Set_myTheta(i_iter);
    [target_policy, target_Lambda, target_RM,target_accuracy]=SIT_f_DPnum(Thres1,Thres2,q1,q2,myTheta,T,myEpsilon);
    Set_Policy(:,:,i_iter)=target_policy;
    Set_Lambda(i_iter)=target_Lambda;   
end
clear i_iter target_policy target_Lambda target_RM target_accuracy,
save Theta_Policy

