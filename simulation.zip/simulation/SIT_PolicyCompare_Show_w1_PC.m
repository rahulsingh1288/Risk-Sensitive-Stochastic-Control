clear all;close all;clc
load Policy_Compare_w1_pC2

% figure;hold on;
% temp_show=(Station_SimuResult.Positive_S+(1/2).*[Station_SimuResult.myTheta,Station_SimuResult.myTheta].*(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2))./Station_SimuResult.mean_S;
% plot(Station_SimuResult.myTheta,sum(temp_show,2),'bx');
% temp_show=(DeliverDebt_SimuResult.Positive_S+(1/2).*[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
% plot(DeliverDebt_SimuResult.myTheta,sum(temp_show,2),'rs');
% % temp_show=(TimeDebt_SimuResult.Positive_S+(1/2).*[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
% % plot(TimeDebt_SimuResult.myTheta,sum(temp_show,2),'k.');
% temp_show=(PackageRR_SimuResult.Positive_S+(1/2).*[PackageRR_SimuResult.myTheta,PackageRR_SimuResult.myTheta].*(PackageRR_SimuResult.SquareP_S-(PackageRR_SimuResult.Positive_S).^2))./PackageRR_SimuResult.mean_S;
% plot(PackageRR_SimuResult.myTheta,sum(temp_show,2),'go');
% % temp_show=(RoundRobin_SimuResult.Positive_S+(1/2).*[RoundRobin_SimuResult.myTheta,RoundRobin_SimuResult.myTheta].*(RoundRobin_SimuResult.SquareP_S-(RoundRobin_SimuResult.Positive_S).^2))./RoundRobin_SimuResult.mean_S;
% % plot(RoundRobin_SimuResult.myTheta,sum(temp_show,2),'bd');
% 
% 
% % legend('Ours', 'DD','TD','PRR','RR')
% legend('Ours','DD','PRR')
% title('Physical \theta-sensitive cost')

figure;hold on;
subplot(1,2,1);hold on;title('throughput for user 1')
plot(Station_SimuResult.myTheta,ones(size(Station_SimuResult.myTheta)).*(Thres(2)/sum(Thres)).*(1-q(1)),'k-');
plot(Station_SimuResult.myTheta,1./Station_SimuResult.mean_S(:,1),'bx');
plot(DeliverDebt_SimuResult.myTheta,1./DeliverDebt_SimuResult.mean_S(:,1),'rs');
plot(PackageRR_SimuResult.myTheta,1./PackageRR_SimuResult.mean_S(:,1),'go');
legend('Reference','Ours','DD','PRR')
subplot(1,2,2);hold on;title('throughput for user 2')
plot(Station_SimuResult.myTheta,ones(size(Station_SimuResult.myTheta)).*(Thres(1)/sum(Thres)).*(1-q(2)),'k-');
plot(Station_SimuResult.myTheta,1./Station_SimuResult.mean_S(:,2),'bx');
plot(DeliverDebt_SimuResult.myTheta,1./DeliverDebt_SimuResult.mean_S(:,2),'rs');
plot(PackageRR_SimuResult.myTheta,1./PackageRR_SimuResult.mean_S(:,2),'go');
legend('Reference','Ours','DD','PRR')