% function for simulation with the optimal policy to get throughput
% salute SIM_simu.m
 function [mean_S,Positive_S,SquareP_S,RiskCost]=SIT_f_simu(Thres1,Thres2,q1,q2,myTheta,target_policy, T_simu)
%% input
% clear all;close all;clc
% Thres1=8; %denote for \pi1
% Thres2=7; %denote for \pi2
% q1=0.01;  %faling prob for user1
% q2=0.8;   %faling prob for user2
% myTheta=0.1; %risk-aversion parameter
%     T=1e6;     %number of total time slot
%     myEpsilon=1e-10; %small value to check equality for double class (relatvie difference)
%      [target_policy, target_Lambda, target_RM,target_accuracy]=SIT_f_DPnum(Thres1,Thres2,q1,q2,myTheta,T,myEpsilon);
% target_policy,
%     target_Lambda,
% T_simu=1e6;
%% input in another way
User_number=2;
qSet=[q1;q2];
Thres_state=[Thres1 Thres2];
%% initialization
current_state=zeros(1,User_number);
n=zeros(1,User_number);
% output
mean_S=zeros(1,User_number);
Positive_S=zeros(1,User_number);
SquareP_S=zeros(1,User_number);
RiskCost=0; % lambda in simulation
% prepare for randomness
rng('shuffle');
s_rSeedRecord=rng;
% check the input
r=exp(myTheta);
%-- intermediate variables
% policy_index t u 
% current_q temp_L;% temp_L is the temporary cost for (S-Pi)^+

%% simulation loops
for t=1:T_simu
    % find current policy z, update Dist_state
    policy_index=min(current_state,Thres_state);
    u=target_policy(policy_index(1)+1,policy_index(2)+1);
    % try transmission, update state & records
    current_q=qSet(u);
    if rand(1)<current_q
        current_state=current_state+1;
        temp_L=0;
    else
        current_state=current_state+1;
        temp_L=max(current_state(u)-Thres_state(u),0);        
        mean_S(u)=(current_state(u))/(n(u)+1)+mean_S(u)*n(u)/(n(u)+1);
        Positive_S(u)=temp_L/(n(u)+1)+Positive_S(u)*n(u)/(n(u)+1);
        SquareP_S(u)=temp_L^2/(n(u)+1)+SquareP_S(u)*n(u)/(n(u)+1);       
        n(u)=n(u)+1;
        current_state(u)=0;        
    end
    RiskCost=temp_L/t+RiskCost*(t-1)/t;
end

%% Manipulate and Demonstration
% mean_S,Positive_S,SquareP_S,RiskCost,
% temp_show=(RiskCost-target_Lambda)/target_Lambda,



