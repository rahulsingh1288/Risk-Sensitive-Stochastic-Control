% funtion to get optimal policy by policy iteration 
% - numerical analysis,policy iteration
% use subfunction-- SIT_f_MyPTMgen.m  
%% input
clear all;close all;clc;
Thres=[8,7]; %denote for [\pi_1,\pi_2]
q=[0.1,0.4];  %faling prob for users
myTheta=0.1; %risk-aversion parameter
myEpsilon=1e-10; %small value to check equality for double class (relatvie difference)
% additional input for this file
thresN_stay=20;
%% initialization
%-output
flag=0; % system flag to see whether achieve optimal
%Z_opt;
%Alpha_opt;
%-intermediate - for state
N_stay=0; % count how long the system stay in the same alpha 
StateSet_Cardinal=(Thres(1)+1)*(Thres(2)+1);
Z_current=2*ones(StateSet_Cardinal,1);Z_past=ones(StateSet_Cardinal,1); %record policy. make some value to facilitate L1,L2
Phi_current=zeros(StateSet_Cardinal,1);Phi_past=zeros(StateSet_Cardinal,1); % record value vector phi
Alpha_current=0;Alpha_past=0; % record alpha --> \lambda =1/\theta ln(\alpha)
%-intermediate - for PTM
%temp_L; % tempt probability transition matrix
    Z_past([0, Thres(2)]*[1;Thres(1)+1]+1)=2; % satisfy basic assumption
L_1=SIT_f_MyPTMgen(Z_past,Thres,q,myTheta); % PTM for all u=1 (except for 0,Pi2)
    Z_current(Thres(1)+1)=1; %satisfy basic assumption (not for Pi1,0)
L_2=SIT_f_MyPTMgen(Z_current,Thres,q,myTheta); % PTM for all u=2 (except for Pi1,0) 
%- other intermediate varibles
%t_LPhi_1,t_LPhi_2,t_LPhi_min, %which is(L*Phi_k)/Alpha_k for L_1, L_2, L_min
%% prepare for initial state
[Phi_past,Alpha_past]=eigs(L_1,1,'LM');
Phi_past=Phi_past./Phi_past(end);
if sum(Phi_past>0)<StateSet_Cardinal || (~(Alpha_past>0))
    error('myError: wrong eigenvalue/vector');
end
%% body for policy iteration
while flag==0 && N_stay<thresN_stay
    % update policy
    Z_current=2*ones(StateSet_Cardinal,1);
    t_LPhi_1=(L_1*Phi_past)./Alpha_past;
    t_LPhi_2=(L_2*Phi_past)./Alpha_past;
    t_LPhi_min=min(t_LPhi_1,t_LPhi_2);    
    Z_current(t_LPhi_1<=t_LPhi_2)=1;
    Z_current([0, Thres(2)]*[1;Thres(1)+1]+1)=2; % to satisfy basic assumption
    Z_current(Thres(1)+1)=1;
    if sum(Z_current==Z_past)==StateSet_Cardinal && max(abs((t_LPhi_min-Phi_past)./Phi_past))<myEpsilon  
    % achieve optimal condition
        flag=1;
        Z_opt=Z_past;
        Alpha_opt=Alpha_past;
        break;
    end

    % update current alpha phi
    temp_L=SIT_f_MyPTMgen(Z_current,Thres,q,myTheta);
    [Phi_current,Alpha_current]=eigs(L_1,1,'LM');
    Phi_current=Phi_current./Phi_current(end);
    if sum(Phi_current>0)<StateSet_Cardinal || (~(Alpha_current>0))
        error('myError: wrong eigenvalue/vector');
    end
    % prepare for next loop    
    if (Alpha_past-Alpha_current)/Alpha_past<myTheta % check whether it stays
        N_stay=N_stay+1;
    else
        N_stay=0;
    end
    if N_stay==20
        (Alpha_past-Alpha_current)/Alpha_past
     end
    Z_past=Z_current;
    Phi_past=Phi_current;
    Alpha_past=Alpha_current;    
    
end
%% demonstrate 
if flag
    reshape(Z_opt,Thres(1)+1,Thres(2)+1),
    Alpha_opt,
end


