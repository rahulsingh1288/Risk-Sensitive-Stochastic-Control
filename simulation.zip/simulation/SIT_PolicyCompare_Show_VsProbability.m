clear all;close all;clc
load Policy_Compare

figure;hold on;
title('Physical cost')
temp_show=(ModiMG_SimuResult.Positive_S+[ModiMG_SimuResult.myTheta,ModiMG_SimuResult.myTheta].*(ModiMG_SimuResult.SquareP_S-(ModiMG_SimuResult.Positive_S).^2))./ModiMG_SimuResult.mean_S;
plot(Set_q(:,1),sum(temp_show,2),'kx');
temp_show=(DeliverDebt_SimuResult.Positive_S+[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
plot(Set_q(:,1),sum(temp_show,2),'ro');
temp_show=(TimeDebt_SimuResult.Positive_S+[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
plot(Set_q(:,1),sum(temp_show,2),'b.');
legend('Modi-MiniGap','DeliverDebt','TimeDebt')