clear all;close all;clc
load Policy_Compare
figure;hold on;
% plot(Station_AnaResult.myTheta,Station_AnaResult.Station_Lambda,'k-')
plot(Station_SimuResult.myTheta,Station_SimuResult.Lambda_simu,'ks')
plot(DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.Lambda_simu,'ro')
plot(TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.Lambda_simu,'bx')
legend('opt', 'DelverDebt','TimeDebt')
title('\Lambda=1/\theta lnE[exp(\theta l(x))]')



figure;hold on;
temp_show=(Station_SimuResult.Positive_S+[Station_SimuResult.myTheta,Station_SimuResult.myTheta].*(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2))./Station_SimuResult.mean_S;
plot(Station_SimuResult.myTheta,sum(temp_show,2),'ks');
temp_show=(DeliverDebt_SimuResult.Positive_S+[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
plot(DeliverDebt_SimuResult.myTheta,sum(temp_show,2),'ro');
temp_show=(TimeDebt_SimuResult.Positive_S+[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
plot(TimeDebt_SimuResult.myTheta,sum(temp_show,2),'bx');
legend('opt', 'DelverDebt','TimeDebt')
title('E[S_i^+]+\theta Var(S_i^+) ( normed by E[S_i])')



% figure;hold on;
% % plot(Station_AnaResult.myTheta,Station_AnaResult.Station_Lambda,'k-')
% plot(Station_SimuResult.myTheta,Station_SimuResult.Lambda_simu,'bs')
% temp_show=(Station_SimuResult.Positive_S+[Station_SimuResult.myTheta,Station_SimuResult.myTheta].*(Station_SimuResult.SquareP_S-(Station_SimuResult.Positive_S).^2))./Station_SimuResult.mean_S;
% plot(Station_SimuResult.myTheta,sum(temp_show,2),'ro');
% legend('Lambda','Physical')
% title('analytical and numerical result for stationary policy')
% 
% figure;hold on;
% plot(Station_SimuResult.myTheta,Station_SimuResult.mean_S,'ks');
% temp_show=(DeliverDebt_SimuResult.Positive_S+[DeliverDebt_SimuResult.myTheta,DeliverDebt_SimuResult.myTheta].*(DeliverDebt_SimuResult.SquareP_S-(DeliverDebt_SimuResult.Positive_S).^2))./DeliverDebt_SimuResult.mean_S;
% plot(DeliverDebt_SimuResult.myTheta,sum(temp_show,2),'ro');
% temp_show=(TimeDebt_SimuResult.Positive_S+[TimeDebt_SimuResult.myTheta,TimeDebt_SimuResult.myTheta].*(TimeDebt_SimuResult.SquareP_S-(TimeDebt_SimuResult.Positive_S).^2))./TimeDebt_SimuResult.mean_S;
% plot(TimeDebt_SimuResult.myTheta,sum(temp_show,2),'bx');

