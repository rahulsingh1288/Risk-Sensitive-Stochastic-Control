% symbolic analysis for certain policy
% assume p1=1-e^2; p2=1-e

% %% input
% clear all;close all;clc;
% syms e positive; % as small amount-epsilon
% syms r positive; % as exp(\theta), requires re<1
% H=3; %threshold for users
% Thres1=H;
% Thres2=H+1;
% p=[1-e,1-e]; %channel reliability
% 
% 
% %% initialization
% V_past=sym(ones(Thres1+1,Thres2+1));
% V_current=sym(ones(Thres1+1,Thres2+1));
% t=0;

%% recurence calculation
for k1=0:Thres1
    for k2=0:Thres2
        % prepare
        Bound1=(k1==Thres1);
        Bound2=(k2==Thres2);
        temp_Multi=r^sym(Bound1+Bound2);
        fail_k1=k1+1-Bound1;
        fail_k2=k2+1-Bound2;
        Success_Value=[V_past(1,fail_k2+1),V_past(fail_k1+1,1)];
        % choose and recurent iteration
        if Thres1-k1<Thres2-k2
            temp_u=1;
        else
            temp_u=2;
        end
        V_current(k1+1,k2+1)=p(temp_u)*Success_Value(temp_u)+(1-p(temp_u))*V_past(fail_k1+1,fail_k2+1);
        V_current(k1+1,k2+1)=V_current(k1+1,k2+1)*temp_Multi;
    end
end

%% update and show
t=t+1,
V_past=V_current;
V_past=simplify(V_past);
V_past=collect(V_past,e),

%% truncate V_past
tV=V_past;
tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
tV_0=tV_get;

tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
tV_1=tV_get;

tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
tV_2=tV_get;

tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
tV_3=tV_get;

% tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
% tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
% tV_4=tV_get;
% 
% tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
% tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
% tV_5=tV_get;
% 
% tV_get=sym(subs(tV,e,0));tV_get=simplify(tV_get);
% tV=(tV-tV_get)/e;tV=simplify(tV);tV=collect(tV,e);
% tV_6=tV_get;

V_past=tV_0+e*tV_1+e^2*tV_2+e^3*tV_3;%+e^4*tV_4+e^5*tV_5+e^6*tV_6;
V_past=simplify(V_past);
V_past=collect(V_past,e),
