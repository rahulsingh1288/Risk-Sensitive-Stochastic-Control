% this file is to generate analysis&simulation results for Policies
%   including Stationary, Switch, Delivery-Debt, Time-Debt
%% input
clear all;close all;clc;
Thres=[6,9];
Set_q=([1e-2  ;0.1 ;0.2 ;0.3])*[1,1.05];
T=1e6; % for value-iteration (initial upper bound of time slots), but not affect in most cases 
myEpsilon=1e-10;
T_simu=1e6;
myTheta=0.05;
User_number=2;
%% initialize
Set_length=length(Set_q);
%-intermediate variables
%mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu
%myTheta, i_iter
save('Policy_Compare','User_number','Set_q','Thres','myTheta','T', 'myEpsilon', 'T_simu');
%% Delivery Debt Policy
DeliverDebt_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
    q=Set_q(i_iter,:);
    % simulation result
    [mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S, Exp_C, Lambda_simu]=SIT_simu_DeliveryDebt(User_number,q,Thres,myTheta,T_simu);
    DeliverDebt_SimuResult.myTheta(i_iter)=myTheta;
    DeliverDebt_SimuResult.mean_S(i_iter,:)=mean_S;
    DeliverDebt_SimuResult.Square_S(i_iter,:)=Square_S;
    DeliverDebt_SimuResult.Exp_S(i_iter,:)=Exp_S;
    DeliverDebt_SimuResult.Positive_S(i_iter,:)=Positive_S;
    DeliverDebt_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    DeliverDebt_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    DeliverDebt_SimuResult.Exp_C(i_iter)=Exp_C;
    DeliverDebt_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','DeliverDebt_SimuResult','-append');
clear DeliverDebt_SimuResult;
%% Time Debt Policy
TimeDebt_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
    q=Set_q(i_iter,:);
    % simulation result
   	[mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_TimeDebt(User_number,q,Thres,myTheta,T_simu);
    TimeDebt_SimuResult.myTheta(i_iter)=myTheta;
    TimeDebt_SimuResult.mean_S(i_iter,:)=mean_S;
    TimeDebt_SimuResult.Square_S(i_iter,:)=Square_S;
    TimeDebt_SimuResult.Exp_S(i_iter,:)=Exp_S;
    TimeDebt_SimuResult.Positive_S(i_iter,:)=Positive_S;
    TimeDebt_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    TimeDebt_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    TimeDebt_SimuResult.Exp_C(i_iter)=Exp_C;
    TimeDebt_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','TimeDebt_SimuResult','-append');
clear TimeDebt_SimuResult;

%% Modified Mini-Gap Policy
ModiMG_SimuResult=struct('myTheta',zeros(Set_length,1),'mean_S',zeros(Set_length,User_number),'Square_S',zeros(Set_length,User_number),'Exp_S',zeros(Set_length,User_number),'Positive_S',zeros(Set_length,User_number),'SquareP_S',zeros(Set_length,User_number),'ExpP_S',zeros(Set_length,User_number),'Exp_C',zeros(Set_length,1),'Lambda_simu',zeros(Set_length,1));
for i_iter=1:Set_length
    q=Set_q(i_iter,:);
    % simulation result
   	[mean_S, Square_S, Exp_S, Positive_S, SquareP_S, ExpP_S,Exp_C, Lambda_simu]=SIT_simu_ModiMGap(User_number,q,Thres,myTheta,T_simu);
    ModiMG_SimuResult.myTheta(i_iter)=myTheta;
    ModiMG_SimuResult.mean_S(i_iter,:)=mean_S;
    ModiMG_SimuResult.Square_S(i_iter,:)=Square_S;
    ModiMG_SimuResult.Exp_S(i_iter,:)=Exp_S;
    ModiMG_SimuResult.Positive_S(i_iter,:)=Positive_S;
    ModiMG_SimuResult.SquareP_S(i_iter,:)=SquareP_S;
    ModiMG_SimuResult.ExpP_S(i_iter,:)=ExpP_S;
    ModiMG_SimuResult.Exp_C(i_iter)=Exp_C;
    ModiMG_SimuResult.Lambda_simu(i_iter)=Lambda_simu;
end
save('Policy_Compare','ModiMG_SimuResult','-append');
clear ModiMG_SimuResult;




clear mean_S Square_S Exp_S Positive_S SquareP_S  ExpP_S Exp_C Lambda_simu;
clear q i_iter;





