% check all the switching policy to get the optimal one
% function [Ratio_opt,Lambda_opt,Alpha_opt]=SIT_num_SwitchPolicy(q,Thres,myTheta)
%% input
clear all;close all;
Thres=[30,30];
q=[0.8,0.5];
myTheta=0.001; %risk-aversion parameter
Delta_ratio=0.1; %what is the tolerable error of the ratio
%% initialization
%-output
Alpha_opt=-1; % optimal alpha (eigenvalue)
%Lambda_opt;
Ratio_opt=0; % optimal ratio compare (K2*Ratio, K1), choose the larger one
%-prepare for iteration
A_bound=0.5/Thres(2);%lower bound for ratio_set
B_bound=Thres(1)/0.5;%upper bound for ratio_set
C_bound=A_bound;
D_bound=B_bound; %1/3 2/3 of the ratio_set,initial value here
%flag; %show whether updated
A_value=-1;
B_value=-1;
%C_value;D_value;
%-other intermediate variables
tN=(Thres(1)+1)*(Thres(2)+1);
tK=zeros(1,2);
%L; %the transition probability matrix
%tRatio; %temp ratio
%tAlpha; %temp allpha
%tX;tZ;tq;tPhi;
%% body
while B_bound-A_bound>Delta_ratio
    if A_value>0
        C_bound=(2*A_bound+B_bound)/3;
        D_bound=(A_bound+2*B_bound)/3;        
    end
    L=zeros(tN,tN);
    
    % update C_Value
    tRatio=C_bound;
    for tX=1:tN
        tK(2)=floor((tX-1)/(Thres(1)+1));
        tK(1)=tX-1-tK(2)*(Thres(1)+1);
        tZ=1;
        if tK(2)*tRatio/Thres(2)>tK(1)/Thres(1)
            tZ=2;
        end        
        tq=q(tZ);
        tCost=sum(tK==Thres);
        % for the fail state;
        tK_fail=min(tK+1,Thres);
        tX_fail=tK_fail*[1;Thres(1)+1]+1;
        L(tX,tX_fail)=tq*exp(myTheta*tCost); % probability * exp(\theta*l(x))
        % for the success state;
        tK_success=tK_fail;
        tK_success(tZ)=0;
        tX_success=tK_success*[1;Thres(1)+1]+1;
        L(tX,tX_success)=(1-tq)*exp(myTheta*tCost);    
    end
    % record and update result
    [tPhi,tAlpha]=eigs(L,1,'LM');
    if (~(tAlpha>0))
        error('myError: wrong eigenvalue/vector');
    end
    C_value=tAlpha;
    
    % update D_value
    tRatio=D_bound;
    for tX=1:tN
        tK(2)=floor((tX-1)/(Thres(1)+1));
        tK(1)=tX-1-tK(2)*(Thres(1)+1);
        tZ=1;
        if tK(2)*tRatio/Thres(2)>tK(1)/Thres(1)
            tZ=2;
        end        
        tq=q(tZ);
        tCost=sum(tK==Thres);
        % for the fail state;
        tK_fail=min(tK+1,Thres);
        tX_fail=tK_fail*[1;Thres(1)+1]+1;
        L(tX,tX_fail)=tq*exp(myTheta*tCost); % probability * exp(\theta*l(x))
        % for the success state;
        tK_success=tK_fail;
        tK_success(tZ)=0;
        tX_success=tK_success*[1;Thres(1)+1]+1;
        L(tX,tX_success)=(1-tq)*exp(myTheta*tCost);    
    end
    % record and update result
    [tPhi,tAlpha]=eigs(L,1,'LM');
    if (~(tAlpha>0))
        error('myError: wrong eigenvalue/vector');
    end
    D_value=tAlpha;
    
    % update the bounds
    if A_value==-1 && B_value==-1
        A_value=C_value;
        B_value=D_value;
        continue;
    end
    flag=0;
    if A_value>=C_value && C_value>D_value  % all possible C>D case
        A_bound=C_bound;A_value=C_value;flag=1;
    else if C_value<D_value && D_value<=B_value  % all possible C<D case
            B_bound=D_bound;B_value=D_value;flag=1;
        else if C_value==D_value   % all possible C=D case
                if D_value<B_value || (A_value<=C_value && D_value==B_value)
                    B_bound=D_bound;B_value=D_value;flag=1;                    
                end
                if A_value>C_value || (A_value==C_value && D_value>B_value)
                    A_bound=C_bound;A_value=C_value;flag=1;
                end
            end
        end
    end
    if flag==0
       temp_show='myError: bounds do not update',
    end    
end
Ratio_opt=B_bound;
Alpha_opt=B_value;
Lambda_opt=log(Alpha_opt)/myTheta;
%% demonstrate
Alpha_opt,
Lambda_opt,
Ratio_opt,
[target_policy, target_Lambda, target_RM,target_accuracy]=SIT_f_DPnum(Thres(1),Thres(2),q(1),q(2),myTheta,1e6,1e-10);
Gap_Ratio=log(Alpha_opt)/myTheta/target_Lambda,
rGap=Gap_Ratio-1,

