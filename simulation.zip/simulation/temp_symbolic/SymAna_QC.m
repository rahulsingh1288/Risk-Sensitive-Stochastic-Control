syms p b n i t;
x=p*b/(p*b+1-b);
s1=sym(1);
%% for 1
% y1=(1-x)*(1-b^i)*b^(n-i)*p*b;% smaller
% y2=(1-x*b^n)*(1-b);
% F=y2-y1;
% F=simplify(F);
% F=simplify(F);
% pretty(F),

%% for lemma 1.1
y1=(s1-b^t)/(s1-b);
y2= b^(t)*x*(s1-b^i)/(s1-b) ;
y=y1+y2;
y=y/(1-b^(t+i)*x);
y=simplify(y);
F=subs(y,t,1)-subs(y,t,0);
F=simplify(F);
[N,D] = numden(F)

