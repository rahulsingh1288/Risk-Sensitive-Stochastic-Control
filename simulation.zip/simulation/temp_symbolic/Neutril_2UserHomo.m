% find stationary distribution (equilibrium)
clear all;
myPi=5;
T1=[1:myPi]'-1;
T2=sym(T1);
syms p;
q=1-p;
T2=p.*(q.^T2);
myPi_sym=sym(myPi);
T2(myPi)=q^(myPi_sym-sym(1));
T1=ones(1,myPi);
T3=sym(T1);
A=T2*T3;
B=eye(myPi);
B=sym(B);
b=zeros(myPi,1);
Aa=zeros(1,myPi);Aa(1)=1;
Aa=sym(Aa);
Bb=zeros(1,myPi);
Bb=sym(Bb);
myW=(A-B)\b,
myW=([A;Aa]-[B;Bb])\[b;1],